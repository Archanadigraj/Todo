export type User = {
  _id: number;
  firstName: string;
  lastName: string;
  email: string;
};
